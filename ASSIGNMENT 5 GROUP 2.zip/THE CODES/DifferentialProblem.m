classdef DifferentialProblem < NumericalMethod
    % ROOTFINDER - Subclass for root-finding methods (NRM and Secant).
    % Inherits from NumericalMethod.

    methods
        % Polymorphism: Implements the abstract 'solve' method.
        function root = solve(obj, initialGuess, method)
            % initialGuess can be a single number (for NRM) or a 2-element array (for Secant).
            % method is a string: 'NRM' or 'Secant'.

            if strcmpi(method, 'NRM')
                root = obj.newtonRaphson(initialGuess);
            elseif strcmpi(method, 'Secant')
                root = obj.secant(initialGuess);
            else
                error('Unknown root-finding method specified.');
            end
        end
    end

    methods (Access = private)
        % Encapsulation: Helper methods are hidden from external access.

        function y = func(~, x)
            % f(x) = x^5 - 2*x^3 + 3*x
            y = x.^5 - 2*x.^3 + 3*x-1;
        end

        function dy = derivFunc(~, x)
            % f'(x) = 5*x^4 - 6*x^2 + 3
            dy = 5*x.^4 - 6*x.^2 + 3;
        end

        function root = newtonRaphson(obj, x0)
            % Newton-Raphson Method (NRM)
            x = x0;
            for i = 1:obj.maxIterations
                x_new = x - obj.func(x) / obj.derivFunc(x);
                if abs(x_new - x) < obj.tolerance
                    root = x_new;
                    return;
                end
                x = x_new;
            end
            warning('NRM failed to converge within max iterations.');
            root = x;
        end

        function root = secant(obj, x_guesses)
            % Secant Method
            x0 = x_guesses(1);
            x1 = x_guesses(2);

            for i = 1:obj.maxIterations
                f0 = obj.func(x0);
                f1 = obj.func(x1);

                if abs(f1 - f0) < eps % Avoid division by zero
                    warning('Secant failed due to near-zero denominator.');
                    root = x1;
                    return;
                end

                x_new = x1 - f1 * (x1 - x0) / (f1 - f0);

                if abs(x_new - x1) < obj.tolerance
                    root = x_new;
                    return;
                end
                x0 = x1;
                x1 = x_new;
            end
            warning('Secant failed to converge within max iterations.');
            root = x1;
        end
    end
end