classdef NumericalMethod
    % NUMERICALMETHOD - Abstract Superclass for all numerical methods.

    properties (Access = protected)
        % Encapsulation: These properties are only accessible within the class
        % and its subclasses.
        maxIterations = 100;
        tolerance = 1e-6;
    end

    methods (Abstract)
        % Abstraction: Forces all subclasses to implement a 'solve' method.
        % This demonstrates polymorphism, as 'solve' will act differently
        % in each subclass.
        result = solve(obj, initialConditions);
    end

    methods
        % Helper method (common to all)
        function disp(~)
            fprintf('NumericalMethod Object - Subclasses must implement "solve".\n');
        end
    end
end