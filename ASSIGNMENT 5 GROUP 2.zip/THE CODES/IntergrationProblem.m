classdef IntergrationProblem < NumericalMethod
    % IVPSOLVER - Subclass for initial value problem solvers (Euler and RK4).
    % Inherits from NumericalMethod.

    properties (Constant)
        T_start = 90; % Initial Temperature
        v_const = 25; % Ambient Velocity/Temperature
        k_const = 0.5; % Cooling Constant
        tspan = 0:1:60; % Time span
    end

    methods
        % Polymorphism: Implements the abstract 'solve' method.
        function [t, T] = solve(obj, method)
            % The 'initialConditions' are fixed in this class's properties
            % to simplify the required high-level structure.
            
            h = obj.tspan(2) - obj.tspan(1); % Step size
            t = obj.tspan;
            numSteps = length(t);
            T = zeros(1, numSteps);
            T(1) = obj.T_start;

            if strcmpi(method, 'Euler')
                [t, T] = obj.euler(T, h);
            elseif strcmpi(method, 'RungeKutta')
                [t, T] = obj.rungeKutta(T, h);
            else
                error('Unknown IVP method specified.');
            end
        end
    end

    methods (Access = private)
        % Encapsulation: Helper methods are hidden from external access.

        function dTdt = odeFunc(obj, ~, T)
            % The ODE function: dT/dt = -k*(T-v)
            dTdt = -obj.k_const * (T - obj.v_const);
        end

        function [t, T] = euler(obj, T, h)
            % Euler's Method
            t = obj.tspan;
            numSteps = length(t);

            for i = 1:numSteps-1
                % T_i+1 = T_i + h * f(t_i, T_i)
                T(i+1) = T(i) + h * obj.odeFunc(t(i), T(i));
            end
        end

        function [t, T] = rungeKutta(obj, T, h)
            % Runge-Kutta 4th Order (RK4)
            t = obj.tspan;
            numSteps = length(t);

            for i = 1:numSteps-1
                ti = t(i);
                Ti = T(i);

                k1 = obj.odeFunc(ti, Ti);
                k2 = obj.odeFunc(ti + h/2, Ti + h/2 * k1);
                k3 = obj.odeFunc(ti + h/2, Ti + h/2 * k2);
                k4 = obj.odeFunc(ti + h, Ti + h * k3);

                % T_i+1 = T_i + h/6 * (k1 + 2*k2 + 2*k3 + k4)
                T(i+1) = Ti + h/6 * (k1 + 2*k2 + 2*k3 + k4);
            end
        end
    end
end