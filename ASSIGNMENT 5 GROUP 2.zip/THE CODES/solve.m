% --- Test Script (e.g., you in a file named test_methods.m) ---
clear
clc
% 1. Create Objects
rootSolver = DifferentialProblem; % RootFinder object
ivpSolver = IntergrationProblem;   % IVPSolver object

fprintf('--- Demonstrating Inheritance and Polymorphism ---\n');

% 2. Test Root-Finding Methods (Differential Problems)
fprintf('\n** Differential Problem Tests (f(x) = x^5 - 2x^3 + 3x) **\n');

% a. Newton-Raphson Method (NRM)
x0_nrm = 0.5;
root_nrm = rootSolver.solve(x0_nrm, 'NRM'); % Polymorphic call to solve
fprintf('NRM Root (initial guess: %.1f): %.8f\n', x0_nrm, root_nrm);

% b. Secant Method
x0_secant = [0.5, 1.0];
root_secant = rootSolver.solve(x0_secant, 'Secant'); % Polymorphic call to solve
fprintf('Secant Root (initial guesses: %.1f, %.1f): %.8f\n', x0_secant(1), x0_secant(2), root_secant);

% 3. Test IVP Solver Methods (Integral Problems)
fprintf('\n** Intergration Problem Class Tests (dT/dt = -0.5*(T-25)) **\n');

% a. Euler Method
[t_e, T_e] = ivpSolver.solve('Euler'); % Polymorphic call to solve
fprintf('Euler method computed %d C temperature values over tspan.\n', length(T_e));

% b. Runge-Kutta 4th Order (RK4)
[t_rk, T_rk] = ivpSolver.solve('RungeKutta'); % Polymorphic call to solve
fprintf('RK4 method computed %d C temperature values over tspan.\n', length(T_rk));