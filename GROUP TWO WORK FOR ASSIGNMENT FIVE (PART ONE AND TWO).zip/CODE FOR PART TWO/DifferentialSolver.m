classdef DifferentialSolver < NumericalSolver
    % DIFFERENTIALSOLVER Implements RK4 for differential problems.
    
    properties (Access = private)
        % Specific properties for differential problem (Kinematic Wave)
        Tspan     % Time interval [t_start, t_end]
        H0        % Initial water depth
        L         % Length of the catchment (m)
        n         % Manning's roughness coefficient
        S0        % Slope of the catchment (m/m)
        RainfallFunc % Function handle for rainfall intensity i(t)
    end
    
    methods
        function obj = DifferentialSolver()
            % Constructor: Set a descriptive method name
            obj.MethodName = 'Runge-Kutta 4th Order (for Kinematic Wave)';
        end
        
        % Implementation of abstract method (Abstraction, Inheritance)
        function setupParameters(obj, Tspan, H0, L, n, S0, RainfallFunc)
            % SETUPPARAMETERS Initializes Kinematic Wave parameters.
            % L: length, n: roughness, S0: slope, H0: initial depth.
            obj.Tspan = Tspan;
            obj.H0 = H0;
            obj.L = L;
            obj.n = n;
            obj.S0 = S0;
            obj.RainfallFunc = RainfallFunc;
        end
        
        % Implementation of abstract method (Abstraction, Polymorphism)
        function [T, H] = solveProblem(obj)
            % SOLVEPROBLEM Solves the differential equation using RK4.
            
            % Check if parameters are set (Encapsulation)
            if isempty(obj.Tspan)
                error('Parameters not set. Call setupParameters first.');
            end
            
            h0 = obj.H0;
            tspan = obj.Tspan;
            dt = 0.1; % Time step
            
            T = tspan(1) : dt : tspan(end);
            N = length(T);
            H = zeros(1, N);
            H(1) = h0;
            
            % Anonymous function for the Kinematic Wave ODE: dh/dt = f(t, h)
            f = @(t, h) obj.RainfallFunc(t) - (h.^(5/3)) / (obj.n * obj.L) * sqrt(obj.S0);
            
            % 4th-Order Runge-Kutta Method (RK4)
            for i = 1:(N-1)
                t = T(i);
                h = H(i);
                
                k1 = dt * f(t, h);
                k2 = dt * f(t + dt/2, h + k1/2);
                k3 = dt * f(t + dt/2, h + k2/2);
                k4 = dt * f(t + dt, h + k3);
                
                H(i+1) = h + (1/6) * (k1 + 2*k2 + 2*k3 + k4);
                
                % Ensure non-negative depth (physical constraint)
                if H(i+1) < 0
                    H(i+1) = 0;
                end
            end
        end
    end
end