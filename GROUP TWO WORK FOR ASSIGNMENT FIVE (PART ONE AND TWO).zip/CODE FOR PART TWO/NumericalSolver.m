classdef (Abstract) NumericalSolver < handle
    % NUMERICALSOLVER Abstract class for all numerical methods.
    % Defines the interface for setting up and solving problems.
    
    properties (Access = protected)
        % Encapsulated properties for problem data
        ProblemData
        MethodName = 'Abstract Solver'
    end
    
    methods (Abstract)
        % Abstract methods that must be implemented by subclasses
        setupParameters(obj, varargin);
        Result = solveProblem(obj);
    end
    
    methods
        % Concrete method to demonstrate polymorphism
        function dispMethod(obj)
            % DISPMETHOD Displays the name of the numerical method.
            disp(['Numerical Method: ', obj.MethodName]);
        end
    end
end