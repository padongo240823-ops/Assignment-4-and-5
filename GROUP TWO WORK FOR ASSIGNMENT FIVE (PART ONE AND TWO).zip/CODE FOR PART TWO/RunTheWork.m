%% Main Script: Assignment Demonstration

% Clear workspace and command window
clear; clc;

%% Part A & B: Storm Water Management Application (Kinematic Wave)

disp('## 1. Storm Water Management (Differential Problem Focus)');
disp('---------------------------------------------------------');

% 1. Create the Differential Solver object (Inheritance)
SolverDiff = DifferentialSolver();

% 2. Define Problem Parameters (Storm Water Kinematic Wave)
T_end = 3600; % Simulation time (1 hour in seconds)
L_c = 100;    % Catchment length (m)
n_m = 0.015;  % Manning's roughness for concrete surface
S0_s = 0.02;  % Catchment slope (m/m)
H0_i = 0.0;   % Initial water depth (m)

% Define the Rainfall Intensity function i(t) (Polymorphism/Encapsulation)
% Simulate a 10-minute (600s) uniform storm of 100 mm/hr
% Convert 100 mm/hr to m/s: 100/1000/3600 = 2.777e-5 m/s
rainfall_rate = 100 / (1000 * 3600); % m/s

% Anonymous function for rainfall intensity i(t)
% 'i_t' is the 'i(t)' in the Kinematic Wave Equation
i_t = @(t) rainfall_rate * (t <= 600); % 100 mm/hr for the first 600s, then 0

% 3. Setup Parameters (Abstraction: Calling the method defined in abstract class)
SolverDiff.setupParameters([0, T_end], H0_i, L_c, n_m, S0_s, i_t);
SolverDiff.dispMethod(); % Polymorphism in action

% 4. Solve the Problem and plot results
[Time, WaterDepth] = SolverDiff.solveProblem();

% Calculate Outflow Rate Q_out (m^2/s) using Manning's Equation for wide channel:
% Q = (1/n) * h^(5/3) * S0^(1/2)
Q_out = (1/n_m) * WaterDepth.^(5/3) * sqrt(S0_s);

% Plotting the results
figure('Name', 'Storm Water Management (Kinematic Wave)');
subplot(2,1,1);
plot(Time/60, WaterDepth, 'LineWidth', 2);
title('Water Depth (h) vs Time (Runoff Hydrograph)');
xlabel('Time (minutes)');
ylabel('Water Depth h (m)');
grid on;

subplot(2,1,2);
plot(Time/60, Q_out, 'r', 'LineWidth', 2);
title('Outflow Rate (Q) vs Time');
xlabel('Time (minutes)');
ylabel('Outflow Rate Q (m^2/s per unit width)');
grid on;

disp(['Final maximum water depth reached: ', num2str(max(WaterDepth), '%.4f'), ' m']);
disp(['Peak Outflow Rate reached: ', num2str(max(Q_out), '%.4f'), ' m^2/s']);


%% Part A: Previous Assignment (Example Integral Problem)

disp(newline);
disp('## 2. General Integral Problem (Previous Assignment Example)');
disp('---------------------------------------------------------');

% 1. Create the Integral Solver object
SolverInt = IntegralSolver();

% 2. Define a function to integrate: f(x) = exp(-x^2)
integrand = @(x) exp(-x.^2);
a_val = 0; % Lower limit
b_val = 2; % Upper limit
N_intervals = 100; % Number of intervals for the Trapezoidal Rule

% 3. Setup Parameters
SolverInt.setupParameters(integrand, a_val, b_val, N_intervals);
SolverInt.dispMethod(); % Polymorphism in action

% 4. Solve the Problem
IntegralResult = SolverInt.solveProblem();

disp(['Integral of exp(-x^2) from ', num2str(a_val), ' to ', num2str(b_val), ' using ', num2str(N_intervals), ' trapezoids:']);
disp(['Result I = ', num2str(IntegralResult, '%.6f')]);