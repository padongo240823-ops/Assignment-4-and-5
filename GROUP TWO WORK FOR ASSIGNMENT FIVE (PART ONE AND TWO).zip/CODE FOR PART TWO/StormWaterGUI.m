classdef StormWaterGUI < matlab.apps.AppBase
    
    % Properties that correspond to app components
    properties (Access = public)
        UIFigure          matlab.ui.Figure
        Panel_Parameters  matlab.ui.container.Panel
        LengthLabel       matlab.ui.control.Label
        LengthField       matlab.ui.control.NumericEditField
        SlopeLabel        matlab.ui.control.Label
        SlopeField        matlab.ui.control.NumericEditField
        RoughnessLabel    matlab.ui.control.Label
        RoughnessField    matlab.ui.control.NumericEditField
        RainfallLabel     matlab.ui.control.Label
        RainfallField     matlab.ui.control.NumericEditField
        DurationLabel     matlab.ui.control.Label
        DurationField     matlab.ui.control.NumericEditField
        RunSimulationButton matlab.ui.control.Button
        Panel_Results     matlab.ui.container.Panel
        UIAxes_Depth      matlab.ui.control.UIAxes
        UIAxes_Outflow    matlab.ui.control.UIAxes
    end
    
    % Class properties
    properties (Access = private)
        SolverDifferential % DifferentialSolver object instance
    end
    
    methods (Access = private)
        
        % Component initialization
        function createComponents(app)
            
            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 850 650];
            app.UIFigure.Name = 'Storm Water Kinematic Wave Solver';
            
            % Create Panel_Parameters
            app.Panel_Parameters = uipanel(app.UIFigure);
            app.Panel_Parameters.Title = 'Catchment & Storm Parameters';
            app.Panel_Parameters.FontWeight = 'bold';
            app.Panel_Parameters.Position = [20 480 810 150];
            
            % --- Input Fields ---
            
            % Length Field
            app.LengthLabel = uilabel(app.Panel_Parameters);
            app.LengthLabel.Position = [20 90 80 22];
            app.LengthLabel.Text = 'Length L (m):';
            app.LengthField = uieditfield(app.Panel_Parameters, 'numeric');
            app.LengthField.Limits = [1 Inf];
            app.LengthField.Value = 100; % Default value
            app.LengthField.Position = [105 90 60 22];
            
            % Slope Field
            app.SlopeLabel = uilabel(app.Panel_Parameters);
            app.SlopeLabel.Position = [185 90 80 22];
            app.SlopeLabel.Text = 'Slope S₀ (m/m):';
            app.SlopeField = uieditfield(app.Panel_Parameters, 'numeric');
            app.SlopeField.Limits = [0.001 Inf];
            app.SlopeField.Value = 0.02; % Default value
            app.SlopeField.Position = [270 90 60 22];
            
            % Roughness Field
            app.RoughnessLabel = uilabel(app.Panel_Parameters);
            app.RoughnessLabel.Position = [350 90 100 22];
            app.RoughnessLabel.Text = 'Roughness n:';
            app.RoughnessField = uieditfield(app.Panel_Parameters, 'numeric');
            app.RoughnessField.Limits = [0.001 Inf];
            app.RoughnessField.Value = 0.015; % Default value
            app.RoughnessField.Position = [450 90 60 22];
            
            % Rainfall Rate Field
            app.RainfallLabel = uilabel(app.Panel_Parameters);
            app.RainfallLabel.Position = [20 40 100 22];
            app.RainfallLabel.Text = 'Rain Rate (mm/hr):';
            app.RainfallField = uieditfield(app.Panel_Parameters, 'numeric');
            app.RainfallField.Limits = [0 Inf];
            app.RainfallField.Value = 100; % Default value
            app.RainfallField.Position = [125 40 60 22];
            
            % Rainfall Duration Field
            app.DurationLabel = uilabel(app.Panel_Parameters);
            app.DurationLabel.Position = [205 40 100 22];
            app.DurationLabel.Text = 'Duration (min):';
            app.DurationField = uieditfield(app.Panel_Parameters, 'numeric');
            app.DurationField.Limits = [1 Inf];
            app.DurationField.Value = 10; % Default value
            app.DurationField.Position = [310 40 60 22];
            
            % Create Run Simulation Button
            app.RunSimulationButton = uibutton(app.Panel_Parameters, 'push');
            app.RunSimulationButton.ButtonPushedFcn = createCallbackFcn(app, @RunSimulationButtonPushed, true);
            app.RunSimulationButton.FontSize = 14;
            app.RunSimulationButton.FontWeight = 'bold';
            app.RunSimulationButton.Position = [550 40 230 72];
            app.RunSimulationButton.Text = 'Run Kinematic Wave Simulation';
            
            % Create Panel_Results
            app.Panel_Results = uipanel(app.UIFigure);
            app.Panel_Results.Title = 'Runoff Hydrographs';
            app.Panel_Results.FontWeight = 'bold';
            app.Panel_Results.Position = [20 20 810 450];
            
            % Create UIAxes_Depth (Top Plot)
            app.UIAxes_Depth = uiaxes(app.Panel_Results);
            app.UIAxes_Depth.Title.String = 'Water Depth (h) vs Time (Runoff Hydrograph)';
            app.UIAxes_Depth.XLabel.String = 'Time (minutes)';
            app.UIAxes_Depth.YLabel.String = 'Water Depth h (m)';
            app.UIAxes_Depth.Position = [20 235 770 200];
            app.UIAxes_Depth.XGrid = 'on';
            app.UIAxes_Depth.YGrid = 'on';
            
            % Create UIAxes_Outflow (Bottom Plot)
            app.UIAxes_Outflow = uiaxes(app.Panel_Results);
            app.UIAxes_Outflow.Title.String = 'Outflow Rate (Q) vs Time';
            app.UIAxes_Outflow.XLabel.String = 'Time (minutes)';
            app.UIAxes_Outflow.YLabel.String = 'Outflow Rate Q (m^2/s per unit width)';
            app.UIAxes_Outflow.Position = [20 20 770 200];
            app.UIAxes_Outflow.XGrid = 'on';
            app.UIAxes_Outflow.YGrid = 'on';
            
            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
        
        % Code that executes after component creation
        function startupFcn(app)
            % Initialize the DifferentialSolver object
            try
                app.SolverDifferential = DifferentialSolver();
            catch ME
                uialert(app.UIFigure, ['Could not initialize DifferentialSolver.m. Please ensure all class files (NumericalSolver.m, DifferentialSolver.m) are on the MATLAB path and error-free. Error: ', ME.message], 'Initialization Error');
            end
        end
        
        % Button pushed function: RunSimulationButton
        function RunSimulationButtonPushed(app, event)
            
            % 1. Get user input parameters
            L_c = app.LengthField.Value;      % Catchment length (m)
            S0_s = app.SlopeField.Value;      % Catchment slope (m/m)
            n_m = app.RoughnessField.Value;   % Manning's roughness
            
            rain_mm_hr = app.RainfallField.Value; % Rainfall rate (mm/hr)
            duration_min = app.DurationField.Value; % Duration (minutes)
            
            T_end = 3600; % Simulation time (1 hour in seconds)
            H0_i = 0.0;   % Initial water depth (m)

            % Basic Input Validation
            if rain_mm_hr <= 0 || duration_min <= 0
                 uialert(app.UIFigure, 'Rainfall Rate and Duration must be positive values.', 'Input Error');
                 return;
            end
            if L_c <= 0 || S0_s <= 0 || n_m <= 0
                 uialert(app.UIFigure, 'Length, Slope, and Roughness must be positive values.', 'Input Error');
                 return;
            end
            
            % 2. Convert units and define functions
            
            % Convert 100 mm/hr to m/s: 100/1000/3600 = 2.777e-5 m/s
            rainfall_rate_ms = rain_mm_hr / (1000 * 3600); % m/s
            duration_s = duration_min * 60; % Duration in seconds

            % Anonymous function for rainfall intensity i(t)
            i_t = @(t) rainfall_rate_ms * (t <= duration_s);
            
            % 3. Setup and Solve the problem using the OOP class
            
            try
                % Setup the parameters
                app.SolverDifferential.setupParameters([0, T_end], H0_i, L_c, n_m, S0_s, i_t);
                
                % Solve the problem
                [Time, WaterDepth] = app.SolverDifferential.solveProblem();
                
                % Calculate Outflow Rate Q_out (m^2/s) using Manning's Equation
                Q_out = (1/n_m) * WaterDepth.^(5/3) * sqrt(S0_s);
                
            catch ME
                 uialert(app.UIFigure, ['Solver Error: ', ME.message], 'Calculation Error');
                 return;
            end
            
            % 4. Plot the results in the GUI axes
            
            % Plot Water Depth (Top Plot)
            plot(app.UIAxes_Depth, Time/60, WaterDepth, 'LineWidth', 2, 'Color', 'b');
            legend(app.UIAxes_Depth, ['Peak h: ', num2str(max(WaterDepth), '%.4f'), ' m'], 'Location', 'NorthWest');
            title(app.UIAxes_Depth, 'Water Depth (h) vs Time (Runoff Hydrograph)');
            app.UIAxes_Depth.XLimMode = 'auto';
            app.UIAxes_Depth.YLimMode = 'auto';
            
            % Plot Outflow Rate (Bottom Plot)
            plot(app.UIAxes_Outflow, Time/60, Q_out, 'LineWidth', 2, 'Color', 'r');
            legend(app.UIAxes_Outflow, ['Peak Q: ', num2str(max(Q_out), '%.4f'), ' m²/s'], 'Location', 'NorthWest');
            title(app.UIAxes_Outflow, 'Outflow Rate (Q) vs Time');
            app.UIAxes_Outflow.XLimMode = 'auto';
            app.UIAxes_Outflow.YLimMode = 'auto';
            
            % Final message
            uialert(app.UIFigure, 'Simulation Complete. Results displayed below.', 'Success', 'Icon', 'success');
        end
    end
    
    % Constructor (used to create the app)
    methods (Access = public)
        function app = StormWaterGUI
            % Create components and run the startup function
            createComponents(app)
            startupFcn(app)
            
            if nargout == 0
                clear app
            end
        end
    end
end
