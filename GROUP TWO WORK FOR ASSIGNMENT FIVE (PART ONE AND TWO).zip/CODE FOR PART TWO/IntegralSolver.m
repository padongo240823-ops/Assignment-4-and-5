classdef IntegralSolver < NumericalSolver
    % INTEGRALSOLVER Implements the Composite Trapezoidal Rule for integrals.
    
    properties (Access = private)
        % Specific properties for integral problem
        IntegrandFunc  % Function handle to be integrated
        A              % Lower limit of integration
        B              % Upper limit of integration
        N              % Number of subintervals
    end
    
    methods
        function obj = IntegralSolver()
            % Constructor
            obj.MethodName = 'Composite Trapezoidal Rule';
        end
        
        % Implementation of abstract method (Abstraction, Inheritance)
        function setupParameters(obj, IntegrandFunc, A, B, N)
            % SETUPPARAMETERS Initializes the integral parameters.
            obj.IntegrandFunc = IntegrandFunc;
            obj.A = A;
            obj.B = B;
            obj.N = N;
        end
        
        % Implementation of abstract method (Abstraction, Polymorphism)
        function I = solveProblem(obj)
            % SOLVEPROBLEM Computes the integral.
            
            % Check if parameters are set (Encapsulation)
            if isempty(obj.IntegrandFunc)
                error('Parameters not set. Call setupParameters first.');
            end
            
            a = obj.A;
            b = obj.B;
            n = obj.N;
            
            h = (b - a) / n; % Width of each subinterval
            
            % Generate x points
            X = a : h : b;
            
            % Evaluate the function at x points
            Y = obj.IntegrandFunc(X);
            
            % Composite Trapezoidal Rule formula:
            % I = h/2 * [y0 + 2*y1 + 2*y2 + ... + 2*y(n-1) + yn]
            I = (h / 2) * (Y(1) + 2*sum(Y(2:end-1)) + Y(end));
        end
    end
end